function X = FFT2(x)
X(1)=x(1)+x(2);
X(2)=x(1)-x(2);
end

